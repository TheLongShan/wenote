package cn.edu.lyu.fxfx.wenote.dao;

import cn.edu.lyu.fxfx.wenote.bean.entity.Comment;
import cn.edu.lyu.fxfx.wenote.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentDao {
    
    // 根据笔记ID查询评论
    public List<Comment> findByNoteId(int noteId) {
        List<Comment> list = new ArrayList<>();
        String sql = "SELECT c.*, u.nickname FROM t_comment c LEFT JOIN t_user u ON c.user_id = u.id WHERE note_id = ? ORDER BY create_time ASC";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, noteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Comment c = new Comment();
                c.setId(rs.getInt("id"));
                c.setNoteId(rs.getInt("note_id"));
                c.setContent(rs.getString("content"));
                c.setUserId(rs.getInt("user_id")); // 关键：需要设置 userId 用于前端判断权限
                c.setUserName(rs.getString("nickname"));
                c.setCreateTime(rs.getTimestamp("create_time"));
                list.add(c);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // 添加评论
    public void add(Comment c) {
        String sql = "INSERT INTO t_comment (note_id, user_id, content) VALUES (?, ?, ?)";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, c.getNoteId());
            ps.setInt(2, c.getUserId());
            ps.setString(3, c.getContent());
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // 【新增】删除评论
    public void delete(int id) {
        String sql = "DELETE FROM t_comment WHERE id = ?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }
}
