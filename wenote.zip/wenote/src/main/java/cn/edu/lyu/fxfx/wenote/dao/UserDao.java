package cn.edu.lyu.fxfx.wenote.dao;

import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import cn.edu.lyu.fxfx.wenote.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    // 登录
    public User login(String username, String password) {
        String sql = "SELECT * FROM t_user WHERE username = ? AND password = ?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return extractUser(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    // 检查用户名存在
    public boolean isUsernameExist(String username) {
        String sql = "SELECT count(*) FROM t_user WHERE username = ?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // 注册
    public void register(User user) {
        String sql = "INSERT INTO t_user (username, password, nickname, role) VALUES (?, ?, ?, 'editor')";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getNickname());
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // 列表查询
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM t_user ORDER BY id ASC";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(extractUser(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // ID查询
    public User findById(int id) {
        String sql = "SELECT * FROM t_user WHERE id = ?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return extractUser(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    // 【核心修改】全能更新方法 (支持动态更新)
    public void update(User user) {
        StringBuilder sql = new StringBuilder("UPDATE t_user SET nickname=?, role=?, username=? ");
        List<Object> params = new ArrayList<>();
        params.add(user.getNickname());
        params.add(user.getRole());
        params.add(user.getUsername()); // 支持修改用户名

        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            sql.append(", password=? ");
            params.add(user.getPassword());
        }
        if (user.getAvatar() != null && !user.getAvatar().isEmpty()) {
            sql.append(", avatar=? ");
            params.add(user.getAvatar());
        }
        
        sql.append(" WHERE id=?");
        params.add(user.getId());

        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // 【新增】删除用户
    public void delete(int id) {
        // 注意：由于有外键约束，直接删除用户可能会报错（如果他发过笔记或评论）。
        // 最好是在数据库设置 ON DELETE CASCADE，或者先删他的关联数据。
        // 这里假设数据库已处理好级联删除，或者该用户是“干净”的。
        String sql = "DELETE FROM t_user WHERE id = ?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // 辅助提取方法
    private User extractUser(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPassword(rs.getString("password"));
        u.setRole(rs.getString("role"));
        u.setNickname(rs.getString("nickname"));
        u.setAvatar(rs.getString("avatar"));
        return u;
    }
}
