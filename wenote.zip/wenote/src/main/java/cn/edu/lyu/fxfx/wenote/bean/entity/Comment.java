package cn.edu.lyu.fxfx.wenote.bean.entity;
import java.util.Date;

public class Comment {
    private Integer id;
    private Integer noteId;
    private Integer userId;
    private String userName; // 用于展示
    private String content;
    private Date createTime;
    
    // Getters and Setters (省略部分，请自行补全或使用IDE生成)
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Integer getNoteId() { return noteId; }
    public void setNoteId(Integer noteId) { this.noteId = noteId; }
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public Date getCreateTime() { return createTime; }
    public void setCreateTime(Date createTime) { this.createTime = createTime; }
}
