package cn.edu.lyu.fxfx.wenote.bean.form;

public class NoteForm {
    private String searchKeyword; // 搜索关键词

    public String getSearchKeyword() { return searchKeyword; }
    public void setSearchKeyword(String searchKeyword) { this.searchKeyword = searchKeyword; }
}
