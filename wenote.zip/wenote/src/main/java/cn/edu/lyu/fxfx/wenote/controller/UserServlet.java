package cn.edu.lyu.fxfx.wenote.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import cn.edu.lyu.fxfx.wenote.service.UserService;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

@WebServlet("/user/*")
@MultipartConfig // 必须加！为了支持头像上传
public class UserServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        User currentUser = (User) req.getSession().getAttribute("currentUser");

        // 1. 个人中心 (所有人都能进)
        if ("/profile".equals(path)) {
            if (currentUser == null) { resp.sendRedirect(req.getContextPath() + "/login.jsp"); return; }
            // 重新查一遍数据库，保证看到的是最新信息
            User latestUser = userService.getUserById(currentUser.getId());
            req.setAttribute("u", latestUser);
            req.getRequestDispatcher("/WEB-INF/view/profile.jsp").forward(req, resp);
            return;
        }

        // 2. 下面是管理员功能，需权限检查
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }

        if ("/list".equals(path)) {
            req.setAttribute("userList", userService.getUserList());
            req.getRequestDispatcher("/WEB-INF/view/user_list.jsp").forward(req, resp);
            
        } else if ("/edit".equals(path)) {
            int id = Integer.parseInt(req.getParameter("id"));
            req.setAttribute("u", userService.getUserById(id));
            req.getRequestDispatcher("/WEB-INF/view/user_edit.jsp").forward(req, resp);
            
        } else if ("/delete".equals(path)) {
            int id = Integer.parseInt(req.getParameter("id"));
            // 防止自杀
            if (id == currentUser.getId()) {
                req.getSession().setAttribute("msg", "不能删除自己！");
            } else {
                userService.deleteUser(id);
            }
            resp.sendRedirect(req.getContextPath() + "/user/list");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        User currentUser = (User) req.getSession().getAttribute("currentUser");

        // 1. 更新个人资料 (所有人可用)
        if ("/updateProfile".equals(path)) {
            if (currentUser == null) return;
            
            // 接收普通字段
            String nickname = req.getParameter("nickname");
            String password = req.getParameter("password");
            
            // 接收头像
            String avatar = handleFileUpload(req);

            User user = new User();
            user.setId(currentUser.getId());
            user.setUsername(currentUser.getUsername()); // 个人中心不准改用户名
            user.setRole(currentUser.getRole());         // 个人中心不准改角色
            user.setNickname(nickname);
            user.setPassword(password);
            user.setAvatar(avatar);

            userService.updateUser(user);
            
            // 更新Session中的信息，立刻生效
            User freshUser = userService.getUserById(currentUser.getId());
            req.getSession().setAttribute("currentUser", freshUser);

            resp.sendRedirect(req.getContextPath() + "/user/profile?success=1");
            return;
        }

        // 2. 管理员更新他人信息
        if ("/adminUpdate".equals(path)) {
            if (currentUser == null || !"admin".equals(currentUser.getRole())) return;

            int id = Integer.parseInt(req.getParameter("id"));
            String username = req.getParameter("username"); // 管理员可以改用户名
            String nickname = req.getParameter("nickname");
            String role = req.getParameter("role");
            String password = req.getParameter("password");
            
            User originalUser = userService.getUserById(id);
            
            User user = new User();
            user.setId(id);
            user.setUsername(username);
            user.setNickname(nickname);
            user.setRole(role);
            user.setPassword(password);
            user.setAvatar(originalUser.getAvatar()); // 管理员修改列表时不涉及头像上传，保持原样

            userService.updateUser(user);
            resp.sendRedirect(req.getContextPath() + "/user/list");
        }
    }

    // 封装文件上传逻辑
    private String handleFileUpload(HttpServletRequest req) throws IOException, ServletException {
        Part filePart = req.getPart("avatarFile");
        if (filePart != null && filePart.getSize() > 0) {
            String rawName = filePart.getSubmittedFileName();
            // 获取后缀名
            String ext = rawName.substring(rawName.lastIndexOf("."));
            String fileName = UUID.randomUUID() + ext;
            
            String uploadPath = getServletContext().getRealPath("/resources/uploads/avatars");
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();
            
            filePart.write(uploadPath + File.separator + fileName);
            return fileName;
        }
        return null;
    }
}
