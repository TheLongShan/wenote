package cn.edu.lyu.fxfx.wenote.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import cn.edu.lyu.fxfx.wenote.bean.form.UserForm; // 使用 Form Bean
import cn.edu.lyu.fxfx.wenote.dao.UserDao;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private UserDao userDao = new UserDao();

    // GET: 只是为了跳转到注册页面（如果直接访问 /register）
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("register.jsp");
    }

    // POST: 处理注册逻辑
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. 使用 Form Bean 接收数据
        UserForm form = new UserForm();
        form.setUsername(req.getParameter("username"));
        form.setPassword(req.getParameter("password"));
        form.setConfirmPassword(req.getParameter("confirmPassword"));
        form.setNickname(req.getParameter("nickname"));

        // 2. 校验
        if (!form.getPassword().equals(form.getConfirmPassword())) {
            req.setAttribute("msg", "两次密码输入不一致！");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        if (userDao.isUsernameExist(form.getUsername())) {
            req.setAttribute("msg", "用户名已存在，换一个吧！");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        // 3. 转换 Entity 并保存
        User user = new User();
        user.setUsername(form.getUsername());
        user.setPassword(form.getPassword());
        user.setNickname(form.getNickname());
        
        userDao.register(user);

        // 4. 成功，跳回登录页
        req.setAttribute("msg", "注册成功，请登录！");
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }
}
