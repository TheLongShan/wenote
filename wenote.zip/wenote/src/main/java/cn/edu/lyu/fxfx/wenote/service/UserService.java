package cn.edu.lyu.fxfx.wenote.service;

import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import cn.edu.lyu.fxfx.wenote.dao.UserDao;
import java.util.List;

public class UserService {
    private UserDao userDao = new UserDao();

    public List<User> getUserList() { return userDao.findAll(); }
    public User getUserById(int id) { return userDao.findById(id); }
    public void updateUser(User user) { userDao.update(user); }
    public void deleteUser(int id) { userDao.delete(id); }
}
