package cn.edu.lyu.fxfx.wenote.util;

import java.sql.*;

public class DBUtil {
    // MySQL 8.0+ 驱动
	private static final String URL = "jdbc:mysql://localhost:3306/wenote?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=utf-8";
    private static final String USER = "root";
    private static final String PWD = "123456"; // <--- 改这里！！！

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConn() throws SQLException {
        return DriverManager.getConnection(URL, USER, PWD);
    }

    public static void close(Connection conn, AutoCloseable... closeables) {
        try {
            for (AutoCloseable c : closeables) {
                if (c != null) c.close();
            }
            if (conn != null) conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
