package cn.edu.lyu.fxfx.wenote.dao;

import cn.edu.lyu.fxfx.wenote.bean.entity.Note;
import cn.edu.lyu.fxfx.wenote.bean.form.NoteForm;
import cn.edu.lyu.fxfx.wenote.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NoteDao {

    /**
     * 查询笔记列表 (支持模糊搜索)
     * 修复点：必须查询 author_id，否则前端无法判断删除权限
     */
    public List<Note> findAll(NoteForm form) {
        List<Note> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT n.*, u.nickname FROM t_note n LEFT JOIN t_user u ON n.author_id = u.id WHERE 1=1 ");
        
        // 动态拼接搜索条件
        boolean hasSearch = false;
        if (form != null && form.getSearchKeyword() != null && !form.getSearchKeyword().trim().isEmpty()) {
            sql.append(" AND (n.title LIKE ? OR n.content LIKE ?) ");
            hasSearch = true;
        }
        
        sql.append(" ORDER BY create_time DESC");

        try (Connection conn = DBUtil.getConn(); 
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            
            // 设置搜索参数
            if (hasSearch) {
                String key = "%" + form.getSearchKeyword().trim() + "%";
                ps.setString(1, key);
                ps.setString(2, key);
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Note n = new Note();
                n.setId(rs.getInt("id"));
                n.setTitle(rs.getString("title"));
                n.setAuthorName(rs.getString("nickname"));
                n.setCreateTime(rs.getTimestamp("create_time"));
                
                // 【核心修复】必须设置 authorId，前端才能判断是否是本人
                n.setAuthorId(rs.getInt("author_id")); 
                
                list.add(n);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    /**
     * 根据ID查询详情
     */
    public Note findById(int id) {
        String sql = "SELECT n.*, u.nickname FROM t_note n LEFT JOIN t_user u ON n.author_id = u.id WHERE n.id = ?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Note n = new Note();
                n.setId(rs.getInt("id"));
                n.setTitle(rs.getString("title"));
                n.setContent(rs.getString("content"));
                n.setFilePath(rs.getString("file_path"));
                n.setAuthorId(rs.getInt("author_id"));
                n.setAuthorName(rs.getString("nickname"));
                n.setCreateTime(rs.getTimestamp("create_time"));
                return n;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    /**
     * 添加笔记
     */
    public void add(Note n) {
        String sql = "INSERT INTO t_note (title, content, author_id, file_path) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, n.getTitle());
            ps.setString(2, n.getContent());
            ps.setInt(3, n.getAuthorId());
            ps.setString(4, n.getFilePath());
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
    /**
     * 删除笔记
     */
    public void delete(int id) {
        String sql = "DELETE FROM t_note WHERE id=?";
        try (Connection conn = DBUtil.getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }
}
