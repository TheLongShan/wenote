package cn.edu.lyu.fxfx.wenote.controller;
// ... (imports 保持不变) ...
import cn.edu.lyu.fxfx.wenote.bean.form.NoteForm; // 引入 NoteForm
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import cn.edu.lyu.fxfx.wenote.bean.entity.Note;
import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import cn.edu.lyu.fxfx.wenote.service.NoteService;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

@WebServlet("/note/*")
@MultipartConfig
public class NoteServlet extends HttpServlet {
    private NoteService noteService = new NoteService();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        
        if ("/list".equals(action)) {
            // 【修改核心】接收搜索参数
            String keyword = req.getParameter("keyword");
            
            // 封装进 NoteForm
            NoteForm form = new NoteForm();
            form.setSearchKeyword(keyword);
            
            // 传给 Service -> DAO
            req.setAttribute("noteList", noteService.getAllNotes(form));
            
            // 回显关键词（让输入框里还保留刚才搜的字）
            req.setAttribute("searchKeyword", keyword);
            
            // 转发回首页 (注意：这里我们假设首页逻辑还是在 index.jsp 处理，但 index.jsp 其实应该只作为视图)
            // 为了简单，我们让 list_frag.jsp 做展示，或者直接转发回 index.jsp 并让 index.jsp 处理显示
            // 既然之前的结构是 index.jsp 包含了 Java 代码调用 Service，那我们需要稍微改一下 index.jsp
            // 为了不改动太大，这里其实只要 index.jsp 能接收 request 里的 list 即可。
        } 
        // ... 其他 detail, delete 分支保持不变 ...
        else if ("/detail".equals(action)) {
            int id = Integer.parseInt(req.getParameter("id"));
            req.setAttribute("note", noteService.getNoteDetail(id));
            req.setAttribute("comments", noteService.getComments(id));
            req.getRequestDispatcher("/detail.jsp").forward(req, resp);
        } else if ("/delete".equals(action)) {
            int id = Integer.parseInt(req.getParameter("id"));
            noteService.deleteNote(id);
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
        }
    }

    // ... doPost 方法保持不变 ...
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if ("/save".equals(req.getPathInfo())) {
             // ... 保持你之前的代码 ...
             // (这里为了省字数省略了，请一定要用你之前的代码！)
             // 注意：最后保存完跳转回 index.jsp
             String title = req.getParameter("title");
             String content = req.getParameter("content");
             Part filePart = req.getPart("file");
             String fileName = null;
             if (filePart != null && filePart.getSize() > 0) {
                 String rawName = filePart.getSubmittedFileName();
                 fileName = UUID.randomUUID() + "_" + rawName; 
                 String uploadPath = getServletContext().getRealPath("/resources/uploads");
                 File uploadDir = new File(uploadPath);
                 if (!uploadDir.exists()) uploadDir.mkdirs();
                 filePart.write(uploadPath + File.separator + fileName);
             }
             User user = (User) req.getSession().getAttribute("currentUser");
             Note note = new Note();
             note.setTitle(title);
             note.setContent(content);
             note.setAuthorId(user.getId());
             note.setFilePath(fileName);
             noteService.addNote(note);
             resp.sendRedirect(req.getContextPath() + "/index.jsp");
        }
    }
}
