package cn.edu.lyu.fxfx.wenote.service;

import cn.edu.lyu.fxfx.wenote.dao.NoteDao;
import cn.edu.lyu.fxfx.wenote.dao.CommentDao;
import cn.edu.lyu.fxfx.wenote.bean.entity.Note;
import cn.edu.lyu.fxfx.wenote.bean.entity.Comment;
import cn.edu.lyu.fxfx.wenote.bean.form.NoteForm; // 引入 Form
import java.util.List;

public class NoteService {
    private NoteDao noteDao = new NoteDao();
    private CommentDao commentDao = new CommentDao();

    // 【修改】接收 Form 参数
    public List<Note> getAllNotes(NoteForm form) { 
        return noteDao.findAll(form); 
    }
    
    public void addNote(Note note) { noteDao.add(note); }
    public void deleteNote(int id) { noteDao.delete(id); }
    public Note getNoteDetail(int id) { return noteDao.findById(id); }
    
    public List<Comment> getComments(int noteId) { return commentDao.findByNoteId(noteId); }
    public void addComment(Comment comment) { commentDao.add(comment); }
    public void deleteComment(int id) { commentDao.delete(id); }
}
