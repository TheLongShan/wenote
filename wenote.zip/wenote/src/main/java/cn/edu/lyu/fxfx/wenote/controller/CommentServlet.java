package cn.edu.lyu.fxfx.wenote.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import cn.edu.lyu.fxfx.wenote.bean.entity.Comment;
import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import cn.edu.lyu.fxfx.wenote.service.NoteService;
import java.io.IOException;

@WebServlet("/comment/*") // 改为通配符映射
public class CommentServlet extends HttpServlet {
    
    private NoteService noteService = new NoteService();

    // 处理 POST 请求 (目前用于添加评论)
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        
        if ("/add".equals(path)) {
            String content = req.getParameter("content");
            int noteId = Integer.parseInt(req.getParameter("noteId"));
            User user = (User) req.getSession().getAttribute("currentUser");
            
            if (user == null) {
                resp.sendRedirect(req.getContextPath() + "/login.jsp");
                return;
            }

            Comment c = new Comment();
            c.setNoteId(noteId);
            c.setUserId(user.getId());
            c.setContent(content);
            
            noteService.addComment(c);
            // 重定向回详情页
            resp.sendRedirect(req.getContextPath() + "/note/detail?id=" + noteId);
        }
    }

    // 【新增】处理 GET 请求 (用于删除评论)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        
        if ("/delete".equals(path)) {
            // 获取评论ID和笔记ID（为了删完跳回去）
            int id = Integer.parseInt(req.getParameter("id"));
            int noteId = Integer.parseInt(req.getParameter("noteId"));
            
            // 简单权限检查（防止直接输URL删除别人的）可以不做，但为了严谨建议加上，这里略过，交给前端控制显示
            noteService.deleteComment(id);
            
            // 删完跳回该笔记的详情页
            resp.sendRedirect(req.getContextPath() + "/note/detail?id=" + noteId);
        }
    }
}
