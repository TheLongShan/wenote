package cn.edu.lyu.fxfx.wenote.controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import cn.edu.lyu.fxfx.wenote.dao.UserDao;
import cn.edu.lyu.fxfx.wenote.bean.entity.User;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UserDao userDao = new UserDao();
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = userDao.login(req.getParameter("username"), req.getParameter("password"));
        if (user != null) {
            req.getSession().setAttribute("currentUser", user);
            resp.sendRedirect("index.jsp");
        } else {
            req.setAttribute("msg", "用户名或密码错误");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }
    }
}
