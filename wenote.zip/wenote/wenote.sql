DROP DATABASE IF EXISTS wenote;
CREATE DATABASE wenote CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE wenote;

-- 设置会话字符集
SET NAMES utf8mb4;

-- ==========================================
-- 用户表 (新增 avatar 字段)
-- ==========================================
CREATE TABLE t_user (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(50) DEFAULT 'editor',
    nickname VARCHAR(100),
    avatar VARCHAR(255) DEFAULT NULL -- 【新增】头像文件名
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 笔记表
-- ==========================================
CREATE TABLE t_note (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT,
    author_id INT,
    file_path VARCHAR(255),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES t_user(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 评论表
-- ==========================================
CREATE TABLE t_comment (
    id INT PRIMARY KEY AUTO_INCREMENT,
    note_id INT,
    user_id INT,
    content VARCHAR(1000),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (note_id) REFERENCES t_note(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES t_user(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 初始化数据
-- ==========================================
INSERT INTO t_user (username, password, role, nickname, avatar) VALUES 
('admin', '123456', 'admin', '管理员大大', NULL),
('editor', '123456', 'editor', '爱学习的小明', NULL);

INSERT INTO t_note (title, content, author_id, create_time) VALUES 
('欢迎使用WeNote', '<p>这是一个支持头像、评论、搜索的<b>全功能版</b>个人笔记系统。</p>', 1, NOW());

INSERT INTO t_comment (note_id, user_id, content) VALUES
(1, 2, '功能越来越完善了，真棒！');
